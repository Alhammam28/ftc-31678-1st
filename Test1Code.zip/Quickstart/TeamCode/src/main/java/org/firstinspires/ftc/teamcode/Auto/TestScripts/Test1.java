package org.firstinspires.ftc.teamcode.Auto.TestScripts;

import static com.sun.tools.javac.code.Lint.LintCategory.PATH;

import static org.firstinspires.ftc.teamcode.pedroPathing.Tuning.follower;

import com.pedropathing.geometry.BezierCurve;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.HeadingInterpolator;
import com.pedropathing.paths.Path;
import com.pedropathing.paths.PathChain;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

public class Test1 extends LinearOpMode {

    private final Pose startPose = new Pose(0, 0, Math.toRadians(0));
    private final Pose pose1 = new Pose(25, 20, Math.toRadians(0));
    private final Pose pose2 = new Pose(25, 20, Math.toRadians(90));



    @Override
    public void runOpMode() {



        PathChain path1 = follower.pathBuilder()
                .addPath(new BezierLine(startPose,pose1))
                .setLinearHeadingInterpolation(pose1.getHeading(), pose2.getHeading(),0.8)
                .addPath(new BezierLine(pose1,pose2))

                .build();

        follower.followPath(path1);


        if (opModeIsActive()){


        }
    }
}
