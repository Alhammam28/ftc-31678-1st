package org.firstinspires.ftc.teamcode.TeleOp.TestScripts;

import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

@TeleOp(name = "Limelight3A_DistanceMotor_PID_Standalone", group = "Sensor")
public class limelightTest3 extends LinearOpMode {

    private Limelight3A limelight;
    private DcMotor liftMotor;


    private static final double CAM_HEIGHT = 0.25;       // متر
    private static final double TARGET_HEIGHT = 0.50;    // متر
    private static final double CAM_MOUNT_ANGLE = 10.0;  // درجات
    private static final double DESIRED_DISTANCE = 0.40; // متر
    private static final double MAX_POWER = 0.6;

    // PID Variables
    private double kP = 0.8;
    private double kI = 0.0;
    private double kD = 0.1;

    private double integralSum = 0;
    private double lastError = 0;
    private long lastTime = 0;

    @Override
    public void runOpMode() {
        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        liftMotor = hardwareMap.get(DcMotor.class, "LFMotor");

        limelight.pipelineSwitch(0);
        limelight.start();

        telemetry.addData(">", "Ready. Press Play.");
        telemetry.update();
        waitForStart();

        lastTime = System.nanoTime();

        while (opModeIsActive()) {
            LLResult result = limelight.getLatestResult();

            if (result != null && result.isValid()) {
                double ty = result.getTy();


                double angleToTargetDeg = CAM_MOUNT_ANGLE + ty;
                double angleRad = Math.toRadians(angleToTargetDeg);

                double distance;
                if (Math.abs(Math.tan(angleRad)) < 1e-6) {
                    distance = Double.POSITIVE_INFINITY;
                } else {
                    distance = (TARGET_HEIGHT - CAM_HEIGHT) / Math.tan(angleRad);
                }

                // PID Control
                double error = DESIRED_DISTANCE - distance;

                long now = System.nanoTime();
                double dt = (now - lastTime) / 1e9;
                lastTime = now;

                // Integral
                integralSum += error * dt;

                // Derivative
                double derivative = (error - lastError) / dt;
                lastError = error;

                double output = (kP * error) + (kI * integralSum) + (kD * derivative);

                double power = Math.max(-MAX_POWER, Math.min(MAX_POWER, output));

                liftMotor.setPower(power);

                telemetry.addData("ty (deg)", ty);
                telemetry.addData("distance (m)", "%.3f", distance);
                telemetry.addData("error", "%.3f", error);
                telemetry.addData("integral", "%.3f", integralSum);
                telemetry.addData("derivative", "%.3f", derivative);
                telemetry.addData("motor power", "%.3f", power);

            } else {
                telemetry.addData("Limelight", "No data");
                liftMotor.setPower(0);
            }

            telemetry.update();
        }

        limelight.stop();
        liftMotor.setPower(0);
    }
}
