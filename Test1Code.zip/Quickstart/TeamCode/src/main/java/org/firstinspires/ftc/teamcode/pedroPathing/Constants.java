package org.firstinspires.ftc.teamcode.pedroPathing;

import static com.sun.tools.javac.code.Lint.LintCategory.PATH;

import com.pedropathing.control.FilteredPIDFCoefficients;
import com.pedropathing.control.PIDFCoefficients;
import com.pedropathing.follower.Follower;
import com.pedropathing.follower.FollowerConstants;
import com.pedropathing.ftc.FollowerBuilder;
import com.pedropathing.ftc.drivetrains.MecanumConstants;
import com.pedropathing.ftc.localization.Encoder;
import com.pedropathing.ftc.localization.constants.ThreeWheelConstants;
import com.pedropathing.paths.PathConstraints;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;

public class Constants {


    public static FollowerConstants followerConstants = new FollowerConstants()
//            .drivePIDFCoefficients(new FilteredPIDFCoefficients(0.1,0.0,0.01,0.6,0.0)) // change it after read drive PID
//            .secondaryDrivePIDFCoefficients(new FilteredPIDFCoefficients(0.1,0,0.01,0.6,0.01) // that's 2nd system

//            .translationalPIDFCoefficients(new PIDFCoefficients(0.1, 0, 0.01, 0)) // that's PID, change it after tuning PID
//            .secondaryTranslationalPIDFCoefficients(new PIDFCoefficients(0.1,0,0.01,0)) // that's 2nd PID system , like this (P,I,D,F)

//            .headingPIDFCoefficients(new PIDFCoefficients(0.1, 0, 0.01, 0))// that's for heading (P,I,D,F)
//            .secondaryHeadingPIDFCoefficients(new PIDFCoefficients(0.1,0,0.01,0)) // 2nd PID heading system

//            .forwardZeroPowerAcceleration(deceleration) // change this after start forward zero power acceleration
//            .lateralZeroPowerAcceleration(deceleration) // change this after start lateral zero power acceleration

//            .useSecondaryTranslationalPIDF(true) // add this if you want  2 PID system for drive
//            .useSecondaryHeadingPIDF(true)
//            .useSecondaryDrivePIDF(true)

            .mass(5); // you have to change it as your robot's weight (kg)

    public static PathConstraints pathConstraints = new PathConstraints(0.99, 100, 1, 1);


    public static Follower createFollower(HardwareMap hardwareMap) {

        return new FollowerBuilder(followerConstants, hardwareMap)
                .pathConstraints(pathConstraints)
                .mecanumDrivetrain(driveConstants)
                .threeWheelLocalizer(localizerConstants)


                .build();
    }
    public static ThreeWheelConstants localizerConstants = new ThreeWheelConstants()

            .forwardTicksToInches(.001989436789) // change it after start forward tuner and write multiplier number
            .strafeTicksToInches(.001989436789) // change it after start lateral tuner and write multiplier number
            .turnTicksToInches(.001989436789)  // change it after start turn tuner and write multiplier number
            .leftPodY(1) // you need to change this offset
            .rightPodY(-1)
            .strafePodX(-2.5)
            .leftEncoder_HardwareMapName("LFMotor") // don"t forget to change this as your odometry port
            .rightEncoder_HardwareMapName("RRMotor")
            .strafeEncoder_HardwareMapName("RFMotor")
            .leftEncoderDirection(Encoder.FORWARD) // you need to change this as your encoder (odometry) direction
            .rightEncoderDirection(Encoder.FORWARD)
            .strafeEncoderDirection(Encoder.FORWARD);

    public static MecanumConstants driveConstants = new MecanumConstants()
            // .xVelocity(velocity) // That's ex change it after start forward velocity tuner,add velocity number
            // .yVelocity(velocity) // That's ex change it after start forward velocity tuner,add velocity number
            .maxPower(1)
            .rightFrontMotorName("RFMotor")
            .rightRearMotorName("RRMotor")
            .leftRearMotorName("LRMotor")
            .leftFrontMotorName("LFMotor")
            .leftFrontMotorDirection(DcMotorSimple.Direction.REVERSE)
            .leftRearMotorDirection(DcMotorSimple.Direction.REVERSE)
            .rightFrontMotorDirection(DcMotorSimple.Direction.FORWARD)
            .rightRearMotorDirection(DcMotorSimple.Direction.FORWARD);
}