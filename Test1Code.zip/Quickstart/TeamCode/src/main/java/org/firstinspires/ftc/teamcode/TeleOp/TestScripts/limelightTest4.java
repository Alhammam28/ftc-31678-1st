package org.firstinspires.ftc.teamcode.TeleOp.TestScripts;

import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;
import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;
import org.firstinspires.ftc.teamcode.pedroPathing.Constants;

@TeleOp
public class limelightTest4 extends OpMode {

    Limelight3A limelight3A;
    BNO055IMU imu; // search about your IMU type ,then change it


    Constants constants = new Constants();



    @Override
    public void init() {
       // bench.init(hardwareMap);
        imu =hardwareMap.get(BNO055IMU.class,"imu");
        BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();
        imu.initialize(parameters);

        limelight3A = hardwareMap.get(Limelight3A.class,"limelight");
        limelight3A.pipelineSwitch(8);

    }

    @Override
    public void start() {
        limelight3A.start();
    }

    @Override
    public void loop() {

        YawPitchRollAngles orientation = imu.getOrientation();

        LLResult llResult = limelight3A.getLatestResult();
        if (llResult != null && llResult.isValid()) {
            Pose3D botpose = llResult.getBotpose();
            telemetry.addData("Target X",llResult.getTx());
            telemetry.addData("Target Y",llResult.getTy());
            telemetry.addData("Target Area",llResult.getTa());
            telemetry.addData("BotPose",botpose.toString());
            telemetry.addData("Yaw",botpose.getOrientation().getYaw());
        }


    }
}
