package org.firstinspires.ftc.teamcode.TeleOp.TestScripts;

import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import java.util.List;

public class limelightTest2 extends LinearOpMode {
    private Limelight3A limelight;

    @Override
    public void runOpMode()
    {
        limelight = hardwareMap.get(Limelight3A.class, "limelight");

        telemetry.setMsTransmissionInterval(11);

        limelight.pipelineSwitch(0);

        /*
         * Starts polling for data.
         */
        limelight.start();

        while (opModeIsActive()) {
            LLResult result = limelight.getLatestResult();
            List<LLResultTypes.FiducialResult> fiducials = result.getFiducialResults();
            List<LLResultTypes.ColorResult> colorTargets = result.getColorResults();

//            for (LLResultTypes.FiducialResult fiducial : fiducials) {
//                int id = fiducial.getFiducialId(); // The ID number of the fiducial
//                double x = detection.getTargetXDegrees(); // Where it is (left-right)
//                double y = detection.getTargetYDegrees(); // Where it is (up-down)
//                double StrafeDistance_3D = fiducial.getRobotPoseTargetSpace().getY();
//                telemetry.addData("Fiducial " + id, "is " + distance + " meters away");
//            }


        }

    }
}
