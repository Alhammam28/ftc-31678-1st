package org.firstinspires.ftc.teamcode.TeleOp.TestScripts;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.IMU;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;
import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;


public class limelightTest6 extends OpMode {
    private Limelight3A limelight;

    private double distance;
   
    private IMU imu;
    @Override
    public void init() {
        limelight = hardwareMap.get(Limelight3A.class,"limelight");
        limelight.pipelineSwitch(8);
        imu = hardwareMap.get(IMU.class,"imu");
        RevHubOrientationOnRobot revHubOrientationOnRobot = new RevHubOrientationOnRobot
                (RevHubOrientationOnRobot.LogoFacingDirection.BACKWARD,
                        RevHubOrientationOnRobot.UsbFacingDirection.BACKWARD);
        imu.initialize(new IMU.Parameters(revHubOrientationOnRobot));
    }
    @Override
    public void start() {
        limelight.start();

    }
    @Override
    public void loop() {
        YawPitchRollAngles orientation = imu.getRobotYawPitchRollAngles();
        limelight.updateRobotOrientation(orientation.getYaw(AngleUnit.DEGREES));

        LLResult llResult = limelight.getLatestResult();
        if (llResult != null && llResult.isValid()){
            Pose3D botPose = llResult.getBotpose_MT2();

            distance = getDistanceFromTage(llResult.getTa());

            telemetry.addData("Distance : ",distance);
            telemetry.addData("Tx : ",llResult.getTx());
            telemetry.addData("Ty : ",llResult.getTy());
            telemetry.addData("Ta : ",llResult.getTa());
            telemetry.addData("BotPose : ",botPose.toString());
            telemetry.update();
        }

    }
    public double getDistanceFromTage(double ta){
        double scale = 30665.95;
        double distance = (scale/ta);
        return distance;
    }
 }
