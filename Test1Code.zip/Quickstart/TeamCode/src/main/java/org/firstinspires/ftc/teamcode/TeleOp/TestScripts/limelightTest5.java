package org.firstinspires.ftc.teamcode.TeleOp.TestScripts;

import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;

@TeleOp(name = "Limelight Y Control Test", group = "Test")
public class limelightTest5 extends OpMode {

    Limelight3A limelight3A;


    DcMotor liftMotor;

    // معاملات التحكم
    double kP = 0.02;        // جرّب وعدّل حسب الحاجة
    double desiredTy = 0.0;  // الهدف: الـ AprilTag يكون في منتصف الكاميرا عمودياً
    double maxPower = 0.6;   // لتجنب السرعة المفرطة

    @Override
    public void init() {
        limelight3A = hardwareMap.get(Limelight3A.class,"limelight");
        limelight3A.pipelineSwitch(8);

        liftMotor = hardwareMap.get(DcMotor.class, "liftMotor"); // ← غيّر الاسم حسب config
        liftMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    }

    @Override
    public void start() {
        limelight3A.start();
    }

    @Override
    public void loop() {
        LLResult llResult = limelight3A.getLatestResult();

        if (llResult != null && llResult.isValid()) {
            double ty = llResult.getTy();
            double error = desiredTy - ty;
            double power = kP * error;

            if (power > maxPower) power = maxPower;
            if (power < -maxPower) power = -maxPower;

            liftMotor.setPower(power);

            Pose3D botpose = llResult.getBotpose();
            telemetry.addData("Target Y (ty)", ty);
            telemetry.addData("Error", error);
            telemetry.addData("Motor Power", power);
            telemetry.addData("BotPose", botpose.toString());
            telemetry.addData("Yaw", botpose.getOrientation().getYaw());
        } else {
            liftMotor.setPower(0.0);
            telemetry.addLine("No valid AprilTag target");
        }
        telemetry.update();
    }
}
