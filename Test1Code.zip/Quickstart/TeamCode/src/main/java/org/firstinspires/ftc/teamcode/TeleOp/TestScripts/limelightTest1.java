package org.firstinspires.ftc.teamcode.TeleOp.TestScripts;

import static org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion.hardwareMap;
import static org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion.telemetry;

import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.IMU;

import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;

public class limelightTest1 extends LinearOpMode {
    BNO055IMU imu;
    private Limelight3A limelight;

    @Override
    public void runOpMode()
    {
        limelight = hardwareMap.get(Limelight3A.class, "limelight");

        telemetry.setMsTransmissionInterval(11);

        limelight.pipelineSwitch(0);

        /*
         * Starts polling for data.
         */
        limelight.start();

        waitForStart();

        while (opModeIsActive()) {
            //////////////////////////////////// MegaTag1

            LLResult result1 = limelight.getLatestResult();
            if (result1 != null) {
                if (result1.isValid()) {
                    Pose3D botpose = result1.getBotpose();
                    telemetry.addData("tx", result1.getTx());
                    telemetry.addData("ty", result1.getTy());
                    telemetry.addData("Botpose", botpose.toString());
                }
            }

            /////////////////////////////////////// MegaTag2

            LLResult result2 = limelight.getLatestResult();
            double robotYaw = imu.getAngularOrientation().firstAngle;
            limelight.updateRobotOrientation(robotYaw);
            if (result2 != null && result2.isValid()) {
                Pose3D botpose_mt2 = result2.getBotpose_MT2();
                if (botpose_mt2 != null) {
                    double x = botpose_mt2.getPosition().x;
                    double y = botpose_mt2.getPosition().y;
                    telemetry.addData("MT2 Location:", "(" + x + ", " + y + ")");
                }
            }

            /////////////////////////////////////////

            LLResult result3 = limelight.getLatestResult();
            if (result3 != null && result3.isValid()) {
                double tx = result3.getTx(); // How far left or right the target is (degrees)
                double ty = result3.getTy(); // How far up or down the target is (degrees)
                double ta = result3.getTa(); // How big the target looks (0%-100% of the image)

                telemetry.addData("Target X", tx);
                telemetry.addData("Target Y", ty);
                telemetry.addData("Target Area", ta);
            } else {
                telemetry.addData("Limelight", "No Targets");
            }
            ////////////////////////////////
        }
    }
}
